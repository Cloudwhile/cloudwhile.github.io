// Tools Class Library Sub class Errorm (Version:BETA-0.0.1.0032 NOT RELEASE) INNER VERSION
// ALPHA TEST
// CREATE BY 404 Software Studio https://www.dofozero.top
// TPCL Copyright (C) 2023-2024 Cloudwhile. All rights reserved.
// Author: Cloudwhile , whitecat.this@gmail.com
// Description:



// Create:2023.5.26





#include "errorm.h"

#include <fstream>
#include <Windows.h>
#include <ctime>


 

ifstream infs;
ofstream outfs;


void err::error::write_log()
{
	time_t now = time(nullptr);
	auto timec = ctime(&now);
	const string LOG_PATH = timec + (string)" " + "log.txt";


	outfs.open(LOG_PATH, ios_base::out);
	outfs.close();
}
