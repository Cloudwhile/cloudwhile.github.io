// Tools Class Library Sub class Errorm (Version:BETA-0.0.1.0032 NOT RELEASE) INNER VERSION
// ALPHA TEST
// CREATE BY 404 Software Studio https://www.dofozero.top
// TPCL Copyright (C) 2023-2024 Cloudwhile. All rights reserved.
// Author: Cloudwhile , whitecat.this@gmail.com
// Description:



// Create:2023.5.26

#define _CRT_SECURE_NO_WARNINGS
#pragma once


#ifndef ERRORM_H
#define ERRORM_H



#include<iostream>


using namespace std;
typedef const int DEFINE;

namespace err {
	class error {
		//system code

		DEFINE FRW_FATAL_ERROR = 1;
		DEFINE OVC_FATAL_ERROR = 2;
		DEFINE ARU_FATAL_ERROR = 3;
		DEFINE UCV_FATAL_ERROR = 4;
		DEFINE SYS_FATAL_ERROR = 5;
		DEFINE CAC_FATAL_ERROR = 6;
	public:
		//public code

		DEFINE WARNING = 7;
		DEFINE ERROR = 8;
		DEFINE FATAL = 9;

		void write_log();
	};
}









#endif